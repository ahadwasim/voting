<?php

error_reporting(E_ALL);
ini_set('display_errors', '1');

include("../include/db.php");

if(isset($_POST['insert'])){

    $q_id = "SELECT candidates_id FROM tb_candidates ORDER BY candidates_id DESC LIMIT 0,4";
    $sql_id = mysqli_query($con, $q_id);
    $row_id = mysqli_fetch_array($sql_id);
    $I = $row_id['candidates_id'];

    $id = $I + 1;
    $name = $_POST['can_name'];
    $post = $_POST['position'];
    $mail = $_POST['email'];
    $image = $_FILES['image']['name'];
    $target = "../img/candidate_profile_pic/".basename($image);

    $sql = "INSERT INTO `tb_candidates`(candidates_id, candidates_name, candidates_position, candidates_email, candidates_pic) VALUES ('$id', '$name', '$post', '$mail', '$image')";
    $query = mysqli_query($con, $sql);
    if($query){
        move_uploaded_file($_FILES['image']['tmp_name'], $target);
           echo "<script>alert('$name added as a $post')</script>";
           echo "<script>window.open('upload','_self')</script>"; 
    } 
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("head.php");  ?>
    <style>
        ::-webkit-scrollbar { width: 0 !important }
        #max{
            display: none;
        }
        table {
          border-collapse: collapse;
          width: 100%;
        }

        th{
          padding: 8px;
          text-align: left;
        }
        td{
          padding: 10px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        #na {
            width: 178px;
            position: relative;
            left: 10px;
            border-bottom: none;
        }
        td input[type="text"]{
          width: 110px;
        }
        td select{
          width: 133px;
        }
        tr:hover {background-color:#f5f5f5;}

        .delete:hover{
            cursor: pointer;
            color: #c1c1c1;
        }
        .edit:hover{
            cursor: pointer;
            color: #000;
        }
    </style>
</head>

<body>
<?php include("navbar.php"); ?>
  <main>
    <div class="wrapper">
      <div class="container">
        <div class="row">
<?php sidebar() ?>
           <div class="span10">
              <div class="content">
                <div class="al"></div>
                <div class="module">                  
                  <button class="collapsible">Add Candidate&ensp;<i class="icon-chevron-down" style="color: black;float: right;"></i></button>
                    <div class="show">
                      <div class="module-body">
                        <form class="form-horizontal row-fluid" method="POST" action="upload.php" enctype="multipart/form-data">

<!-- Candidate's Name: -->
                    <div class="control-group">
                      <label for="Name" class="control-label">Candidate's Name:</label>
                        <div class="controls">
                          <input class="span8" placeholder="Name" type="text" name="can_name" required />
                        </div>
                    </div>

<!-- Candidate's Position: -->
                    <div class="control-group">
                      <label for="Positions" class="control-label">Positions:</label>
                        <div class="controls">
                          <select class="span8" name="position">
                            <option>Select a position</option>
<?php 
                                $query = "select * from tb_positions";
                                $sql = mysqli_query($con, $query);
                                while ($row=mysqli_fetch_array($sql)){
                                $ID = $row['positions_id'];
                                $posts = $row['positions_name'];
                                echo "<option value='$posts'>$posts</option>";    
                                }
?>
                          </select>
                        </div>
                      </div><br>

<!-- Candidate's Email: -->
                    <div class="control-group">
                      <label for="Email" class="control-label">Candidate's Email:</label>
                        <div class="controls">
                          <input type="email" class="span8" placeholder="Email" name="email" id="productcost" />
                        </div>
                    </div>


<!-- Candidate's Picture: -->
                    <div class="control-group">
                      <label for="Product Image" class="control-label">Candidate's Picture:</label>
                        <div class="controls">
                          <input class="span8" type="file" name="image" id="image" />
                        </div>
                    </div>

<!-- Upload Button -->
                    <div class="control-group">
                      <div class="controls">
                        <button title="Update Profile" type="submit" class="btn" name="insert">Upload</button>
                      </div>
                    </div>
                </form>
              </div>
            </div>
          </div>


                <!-- Table -->
                        <div class="module">         
                            <div class="module-body">
                              <div id="show_def">
                                <table>
                                    <tr>
                                      <th>S. No.</th>
                                      <th>Name</th>
                                      <th>Position</th>
                                      <th>Email</th>
                                      <th>Votes</th>

                                      <th><button class="btn btn-inverse" id="edit" onclick="editDiv()" style="float: right">Edit <i class="icon-pencil"></i></button></th>
                                    </tr> 
<?php
            
            $q = mysqli_query($con, "SELECT * FROM tb_candidates ORDER BY candidates_position ASC");
            $count = 0;
            while($r = mysqli_fetch_array($q)){
            $count++;
            $can_id = $r['candidates_id'];
            $can_img = $r['candidates_pic'];
            $can_name = $r['candidates_name'];
            $can_pos = $r['candidates_position'];
            $can_email = $r['candidates_email'];
            $can_vote = $r['candidate_cvotes'];
            // $I = 'id_'.$pos_id1;
            // $J = 'l_'.$pos_id1;
?>
                                    <tr>
                                      <td><?=$count?></td>
                                      <td><input type="text" value="<?=$can_name?>" readonly></td>
                                      <td><input type="text" value="<?=$can_pos?>" readonly></td>
                                      <td><input style="width: 140px" type="text" value="<?=$can_email?>" readonly/ ></td>
                                      <td style="text-align: left;"><?=$can_vote?></td>
                                      <td style="width: 170px">
                                        
                                      </td>
                                    </tr>
<?php
            }
?>

                                    
                                  </table><br>

                              </div>
                              <!-- /hide -->

                              <div id="show_after" class="hide">
                                <table>
                                    <tr>
                                      <th>S. No.</th>
                                      <th>Name</th>
                                      <th>Position</th>
                                      <th>Email</th>
                                      <th>Votes</th>

                                      <th><button class="btn btn-inverse" id="edit" onclick="editDiv1()" style="float: right">Cancel <i class="icon-remove-circle"></i></button></th>
                                    </tr> 
<?php
            
            $q1 = mysqli_query($con, "SELECT * FROM tb_candidates ORDER BY candidates_position ASC");
            $count = 0;
            while($r1 = mysqli_fetch_array($q1)){
            $count++;
            $can_id1 = $r1['candidates_id'];
            $can_img1 = $r1['candidates_pic'];
            $can_name1 = $r1['candidates_name'];
            $can_pos1 = $r1['candidates_position'];
            $can_email1 = $r1['candidates_email'];
            $can_vote1 = $r1['candidate_cvotes'];
            $I = 'nam_'.$can_id1;
            $J = 'mail_'.$can_id1;
            $L = 'sel_'.$can_id1;
?>
           
                                    <tr>
                                      <td><?=$count?></td>
                                      <td><input type="text" id="<?=$I?>" value="<?=$can_name1?>"></td>
                                      <td>
                                      <select id="<?=$L?>">
                                        <option value="<?=$can_pos1?>"><?=$can_pos1?></option>
                          <?php
                                $query = "select * from tb_positions";
                                $sql = mysqli_query($con, $query);
                                while ($row=mysqli_fetch_array($sql)){
                                $ID = $row['positions_id'];
                                $posts = $row['positions_name'];
                                echo "<option value='$posts'>$posts</option>";    
                                }
                          ?>           </select>

                                        <!-- <input type="text" value="<?=$can_pos1?>"> -->
                                      </td>
                                      <td><input type="text" id="<?=$J?>" style="width: 140px" value="<?=$can_email1?>"></td>
                                      <td style="text-align: left;"><?=$can_vote1?></td>
                                      <td id="na">
                                        <span class='edit btn btn-info' id='<?php echo 
                                        $can_id1; ?>'>Update <i class="icon-edit"></i></span>&ensp;
                                        <span class='delete btn btn-danger' id='<?php echo $can_id1; ?>'>Delete <i class="icon-remove"></i></span>
                                      </td>
                                    </tr>
<?php
            }
?>
                                    
                                  </table><br> 


                 <div class="module">
                    <div class="module-head">
                      <h3>Add Candidates</h3>
                    </div>
                 <div class="module-body">
<!--  <div class="alert">
      <button type="button" class="close" data-dismiss="alert">×</button>
      <strong>Warning!</strong> Something fishy here!
      </div>
      <div class="alert alert-error">
      <button type="button" class="close" data-dismiss="alert">×</button>
      <strong>Oh snap!</strong> Whats wrong with you?
      </div>
      <div class="alert alert-success">
      <button type="button" class="close" data-dismiss="alert">×</button>
      <strong>Well done!</strong> Now you are listening me :)
      </div>
 -->
    <br />
                <form class="form-horizontal row-fluid" method="POST" action="upload.php" enctype="multipart/form-data">

<!-- Candidate's Name: -->
                    <div class="control-group">
                      <label for="Name" class="control-label">Candidate's Name:</label>
                        <div class="controls">
                          <input class="span8" placeholder="Name" type="text" name="can_name" required />
                        </div>
                    </div>

<!-- Candidate's Position: -->
                    <div class="control-group">
                      <label for="Positions" class="control-label">Positions:</label>
                        <div class="controls">
                          <select class="span8" name="position">
                            <!-- <option>Select a position</option> -->
<?php 
                                $query = "select * from tb_positions";
                                $sql = mysqli_query($con, $query);
                                while ($row=mysqli_fetch_array($sql)){
                                $ID = $row['positions_id'];
                                $posts = $row['positions_name'];
                                echo "<option value='$posts'>$posts</option>";    
                                }
?>
                          </select>
                        </div>
                      </div><br>

<!-- Candidate's Email: -->
                    <div class="control-group">
                      <label for="Email" class="control-label">Candidate's Email:</label>
                        <div class="controls">
                          <input type="email" class="span8" placeholder="Email" name="email" id="productcost" />
                        </div>
                    </div>


<!-- Candidate's Picture: -->
                    <div class="control-group">
                      <label for="Product Image" class="control-label">Candidate's Picture:</label>
                        <div class="controls">
                          <input class="span8" type="file" name="image" id="image" />
                        </div>
                    </div>

<!-- Upload Button -->
                    <div class="control-group">
                      <div class="controls">
                        <button title="Update Profile" type="submit" class="btn" name="insert">Upload</button>
                      </div>
                    </div>
                </form>
              </div>
              <!-- module-body -->
            </div>
            <!-- /module -->
          </div>
          <!-- /show_after -->
          </div>
          <!--/.content-->
        </div>
        <!--/.span9-->
      </div>
     <!--/.row-->
    </div>
    <!--/.container-->
  </div>
  <!--/.wrapper-->
</main>
<div id="hideme" style="display: none;">

</body>
<!-- </body> -->
<!-- footer -->
<?php include('../include/footer.html'); ?>
<!-- /footer -->
</html>

<script>

    $(document).ready(function(){
      $('.collapsible').click(function(){
        $('.show').toggle(360);
      });

    // Delete 
    $('.delete').click(function(){
        var el = this;

        // Delete id
        var id = this.id;
        // alert(id);
        
        // AJAX Request
        $.ajax({
            url: 'update/candidate_update.php',
            type: 'POST',
            data: { id:id },
            success: function(response){

                if(response == 1){
                    // Remove row from HTML Table
                    $(el).closest('tr').css('background','tomato');
                    $(el).closest('tr').fadeOut(800,function(){
                        $(this).remove();
                    });
                }else{
                    alert('Invalid ID.');
                }
            }
            });
        });
    });




    $(document).ready(function(){
        $('.edit').click(function(){
            var id = this.id;
            var name = $('#nam_'+id).val();
            var pos = $('#sel_'+id).val();
            var mail = $('#mail_'+id).val();
            // alert (id+' '+name+' '+mail+' '+info+' '+pos);

            $.ajax({
                url: 'update/candidate_update.php',
                type: 'POST',
                data: 'id1='+id+'&name='+name+'&pos='+pos+'&mail='+mail,

            success: function(response){

                if(response == 1){
                    // Remove row from HTML Table
                    // setTimeout(location.reload.bind(location), 1000);
                    $('.al').html(
                      '<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert">×</button><strong style="font-size:20px">Updated!</strong><br><br><a href="upload" class="btn btn-info">Reload Page <i class="icon-repeat"></i></a>&ensp;&ensp;&ensp;<button type="button" class="btn btn-info" data-dismiss="alert">Cancle <i class="icon-remove"></i></button></div>'
                      );
                }else{
                    alert('Invalid ID.');
                }
            }
            });
        });
    });

</script>