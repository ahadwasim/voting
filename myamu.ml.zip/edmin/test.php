<?php
session_start();
ob_start();

$username = $_GET['pass'];

$_SESSION['username'] = $username;
header('Location:index');
?>