<?php

$host = "localhost"; /* Host name */
$user = "id10972916_root"; /* User */
$password = "ahad1122"; /* Password */
$dbname = "id10972916_vote"; /* Database name */

$con = mysqli_connect($host, $user, $password,$dbname);
// Check connection
if (!$con) {
  die("Connection failed: " . mysqli_connect_error());
}
?>
